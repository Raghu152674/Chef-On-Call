document.getElementById('reservationForm').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevent the default form submission behavior

    // Collect form data
    const formData = {
        location: document.getElementById('location').value,
        date: document.getElementById('date').value,
        time: document.getElementById('time').value
    };

    // Send the form data via AJAX to the /submit route
    fetch('/submit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.text()) // Assuming your backend returns an HTML page
    .then(data => {
        // Handle successful response
        alert('Reservation submitted successfully!');
        window.location.href = '/chefs'; // Redirect to the 'chefs.html' page
    })
    .catch(error => {
        // Handle any errors that occurred during the request
        console.error('Error:', error);
        alert('An error occurred while submitting the reservation.');
    });
});