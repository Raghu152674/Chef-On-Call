
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevent default form submission

    // Collect form data
    const formData = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        message: document.getElementById('message').value
    };

    // Send form data via AJAX (fetch API) as JSON
    fetch('/contacts', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'  // Send data as JSON
        },
        body: JSON.stringify(formData)  // Convert form data to JSON
    })
    .then(response => response.json())  // Parse the response as JSON
    .then(data => {
        if (data.success) {
            alert('Message sent successfully!');  // Show success message
            document.getElementById('contactForm').reset();  // Clear form
        } else {
            alert('Error: ' + data.error);  // Show error message
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while sending the message.');
    });
});
