from flask import Flask, render_template,url_for,redirect,request,jsonify
from pymongo import MongoClient
from werkzeug.security import generate_password_hash


app = Flask(__name__)

@app.route('/')
def demo():
    return render_template('demo.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/payment')
def payment():
    return render_template('payment.html')

@app.route('/catering')
def catering():
    return render_template('catering.html')


@app.route('/testimonials')
def testimonials():
    return render_template('testimonials.html')


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    return render_template('contact.html')

@app.route('/timing')
def timing():
    return render_template('timing2.html')
  

#BOOKING


client = MongoClient('mongodb://localhost:27017/')
db = client['form_database']
collection = db['form_collection']

@app.route('/submit', methods=['POST'])
def submit():
    # Get the form data from the request
    location = request.form.get('location')
    date = request.form.get('date')
    time = request.form.get('time')

    # Store the data in MongoDB
    form_data = {
        'location': location,
        'date': date,
        'time': time
    }

    # Insert the data into the MongoDB collection
    collection.insert_one(form_data)

    # Redirect or render a template after successful submission
    return render_template('chefs.html')


#CONTACTS


client = MongoClient('mongodb://localhost:27017/')
db = client['form_database']
contacts_collection = db['contacts']

@app.route('/contacts', methods=['POST'])
def contacts():
    try:
        # Get the form data from the AJAX request (JSON format)
        data = request.get_json()
        name = data.get('name')
        email = data.get('email')
        message = data.get('message')

        # Ensure all required fields are provided
        if not name or not email or not message:
            return jsonify({'success': False, 'error': 'Missing required fields'}), 400

        # Store the data in MongoDB
        contact_data = {
            'name': name,
            'email': email,
            'message': message
        }
        contacts_collection.insert_one(contact_data)

        # Return a success response
        return jsonify({'success': True})

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    


    #sign up


client = MongoClient('mongodb://localhost:27017/')
db = client['user_database']
users_collection = db['users']

@app.route('/register', methods=['POST'])
def register():
    try:
        # Get form data from the AJAX request
        data = request.get_json()
        name = data.get('name')
        email = data.get('email')
        password = data.get('password')

        # Validate the input
        if not name or not email or not password:
            return jsonify({'success': False, 'error': 'Missing required fields'}), 400

        # Hash the password for security
        hashed_password = generate_password_hash(password)

        # Store the user data in MongoDB
        user_data = {
            'name': name,
            'email': email,
            'password': password
        }
        users_collection.insert_one(user_data)

        # Return success response
        return jsonify({'success': True})

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500



#sign IN

client = MongoClient('mongodb://localhost:27017/')
db = client['user_database']
users_collection = db['users']

@app.route('/login', methods=['GET','POST'])
def login():
    try:
        # Get form data from the AJAX request
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')

        # Validate the input
       # if not email or not password:
          #  return jsonify({'success': False, 'error': 'Missing email or password'}), 400

        # Find the user by email
   #     user = users_collection.find_one({'email': {'$regex': f'^{email}$', '$options': 'i'}})
  #      if user is None:
 #           return jsonify({'success': False, 'error': 'User not found'}), 404
#
        # Check if the password matches
       # if not check_password_hash(user['password'], password):
     #       return jsonify({'success': False, 'error': 'Invalid password'}), 401

        # If everything is correct, return success
        return jsonify({'success': True})

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


#payment 
client = MongoClient('mongodb://localhost:27017/')
db = client['paymentDB']
payments_collection = db['payments']

@app.route('/submit-payment', methods=['POST'])
def submit_payment():
    try:
        data = request.json
        name = data['name']
        card_number = data['cardNumber']
        expiry_date = data['expiryDate']
        cvv = data['cvv']
        
        # Save the payment details to MongoDB
        payment_data = {
            'name': name,
            'card_number': card_number,
            'expiry_date': expiry_date,
            'cvv': cvv  # Ensure not to store CVV in plain text in a real-world application
        }
        payments_collection.insert_one(payment_data)
        
        return jsonify({'success': True}), 200
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'success': False}), 500




#routes

@app.route('/chefs')
def chefs():
    return render_template('chefs.html')


@app.route('/rating1')
def rating1():
    return render_template('rating1.html')

@app.route('/rating02')
def rating02():
    return render_template('rating02.html')

@app.route('/rating3')
def rating3():
    return render_template('rating3.html')

@app.route('/rating4')
def rating4():
    return render_template('rating4.html')

@app.route('/rating5')
def rating5():
    return render_template('rating5.html')

@app.route('/rating6')
def rating6():
    return render_template('rating6.html')

@app.route('/signin')
def signin():
    return render_template('signin.html')


if __name__ == '__main__':
    app.run(debug=True)
